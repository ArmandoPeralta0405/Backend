// src/dbConfig.ts
//PRODUCCION

export const dbConfig = {
    host: '50.31.188.104', // Cambia esto al host de tu base de datos
    user: 'datasys_avsr', // Cambia esto a tu nombre de usuario de MariaDB
    password: '@Aapm2023', // Cambia esto a tu contraseña de MariaDB
    database: 'datasys_avsr', // Cambia esto al nombre de tu base de datos
    port: 3306
};

/*
//LOCAL
export const dbConfig = {
  host: 'localhost', // Cambia esto al host de tu base de datos
  user: 'root', // Cambia esto a tu nombre de usuario de MariaDB
  password: '', // Cambia esto a tu contraseña de MariaDB
  database: 'clinicaveterinariaBD', // Cambia esto al nombre de tu base de datos
  port: 3306
};
*/
  