// src/models/rolModel.ts
export interface RolModel {
    rol_id: number;
    descripcion: string;
}
