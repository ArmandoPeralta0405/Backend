// src/models/tipo_programaModel.ts
export interface TipoProgramaModel {
    tipo_programa_id: number;
    descripcion: string;
}
