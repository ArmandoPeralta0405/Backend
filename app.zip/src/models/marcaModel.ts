// src/models/marcaModel.ts
export interface MarcaModel {
    marca_id: number;
    descripcion: string;
}
