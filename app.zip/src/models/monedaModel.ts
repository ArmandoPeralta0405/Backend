// src/models/monedaModel.ts
export interface MonedaModel {
    moneda_id: number;
    descripcion: string;
    abreviacion: string;
}
