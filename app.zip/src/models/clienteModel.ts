// src/models/clienteModel.ts
export interface ClienteModel {
    cliente_id: number;
    nombre: string;
    apellido: string;
    cedula: string;
    telefono: string;
    direccion: string;
    estado: boolean;
}


