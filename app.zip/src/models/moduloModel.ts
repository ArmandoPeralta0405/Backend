// src/models/moduloModel.ts
export interface ModuloModel {
    modulo_id: number;
    descripcion: string;
    abreviacion: string;
    estado: boolean;
}
