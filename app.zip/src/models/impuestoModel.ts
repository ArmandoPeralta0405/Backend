// src/models/impuestoModel.ts
export interface ImpuestoModel {
    impuesto_id: number;
    descripcion: string;
    valor: number;
}
