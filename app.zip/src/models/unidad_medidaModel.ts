// src/models/unidad_medidaModel.ts
export interface UnidadMedidaModel {
    unidad_medida_id: number;
    descripcion: string;
    abreviacion: string;
}
