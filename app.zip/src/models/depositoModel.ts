// src/models/depositoModel.ts
export interface DepositoModel {
    deposito_id: number;
    descripcion: string;
}
